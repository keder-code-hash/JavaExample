

class testMain {

    public static void main(String[] args){


        LightMotorVehicle lmv=new LightMotorVehicle(123.4,234,"Honda");
        LightMotorVehicle lmv1=new LightMotorVehicle(123.4,234,"Honda");
        LightMotorVehicle lmv2=new LightMotorVehicle(123.4,234,"Honda");
        
        System.out.println(lmv.toString());
        System.out.println(lmv1.toString());
        System.out.println(lmv2.toString());

        
        

    }    
}
