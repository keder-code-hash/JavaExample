

public class ComplexNum {
	int realPart;
	int complexPart;
	
	
	public ComplexNum() {
		this.realPart = 0;
		this.complexPart = 0;
	}
	
	
}
