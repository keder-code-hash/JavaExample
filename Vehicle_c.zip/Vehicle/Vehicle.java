class Vehicle {
    static int id=100001;
    int vehicleId;
    String companyName;
    int price;


    Vehicle(int price,String companyName){
        this.price=price;
        this.companyName=companyName;
        this.vehicleId=id++;
    }    


    @Override
    public String toString() {
        return "Vechicle [comapnyName=" + companyName + ", price=" + price + ", vehicleId=" + vehicleId + "]";
    }

}
