// we can't instatiate an object of a person

abstract class Person {
    String phNo;
    String name;
    String type;
    Person(String phNo, String name,String type) {
        this.phNo = phNo;
        this.name = name;
        this.type=type;
    }

    @Override
    public String toString() {
        return "Person [name=" + name + ", phNo=" + phNo + ", type=" + type + "]";
    }
}