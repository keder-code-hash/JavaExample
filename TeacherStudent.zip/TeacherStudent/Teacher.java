class Teacher extends Person {

	Teacher(String name, String phNo) {
		super(phNo, name,"teacher");
	}

	public String getName() {
		return this.name;
	}


	public String getType() {
		return this.type;
	}

	public String getPhNo() {
		return this.phNo;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setphNo(String phNo) {
		this.phNo = phNo;
	}
}