abstract class Shape{
	abstract void calculateArea();
	abstract void display();
}
